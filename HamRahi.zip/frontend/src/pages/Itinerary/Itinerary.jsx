// Itinerary.jsx
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "primereact/button";
import { Chips } from "primereact/chips";
import { Dropdown } from "primereact/dropdown";
import { InputNumber } from "primereact/inputnumber";
import { Message } from "primereact/message";
import api from "../../services/api";

const budgetOptions = ["Low", "Medium", "High"].map((value) => ({ label: value, value }));
const styleOptions = ["Solo", "Couple", "Family", "Friends"].map((value) => ({ label: value, value }));

export default function Itinerary() {
  const location = useLocation();
  const prefilledPlaceId = location.state?.placeId;

  const [form, setForm] = useState({
    placeId: prefilledPlaceId || "",
    days: 5,
    budget: "Medium",
    travelStyle: "Friends",
    interests: ["Food", "Culture"],
  });
  
  const [itinerary, setItinerary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (prefilledPlaceId) {
      setForm((prev) => ({ ...prev, placeId: prefilledPlaceId }));
    }
  }, [prefilledPlaceId]);

  // If no placeId is provided, guide the user to choose one from exploration first
  if (!prefilledPlaceId) {
    return (
      <section className="min-h-screen bg-[var(--bg-base)] text-[var(--text-primary)] px-5 pb-20 pt-[120px] flex items-center justify-center">
        <div className="max-w-[500px] text-center rounded-[var(--radius-lg)] border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-8 shadow-xl">
          <i className="pi pi-sparkles text-5xl text-[var(--color-teal)] mb-6 block animate-pulse" />
          <h2 className="text-3xl font-extrabold tracking-tight">Select a Destination First</h2>
          <p className="mt-4 text-sm text-[var(--text-secondary)] leading-6">
            AI itineraries are custom-generated for specific destinations. Please select a destination from the Explore board to begin planning.
          </p>
          <Button as={Link} to="/#destinations" label="Explore Destinations" icon="pi pi-compass" className="mt-6 font-bold" />
        </div>
      </section>
    );
  }

  const updateField = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
    setError("");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    setItinerary(null);

    try {
      const { data } = await api.post("/itinerary/generate", form);
      setItinerary(data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not generate itinerary.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="min-h-screen bg-[var(--bg-base)] text-[var(--text-primary)] px-5 pb-20 pt-[120px] transition-colors duration-300">
      <div className="mx-auto grid max-w-[1180px] gap-8 lg:grid-cols-[400px_1fr]">
        
        {/* Planning Form */}
        <form
          onSubmit={handleSubmit}
          className="rounded-[28px] border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-sm self-start no-print md:p-8"
        >
          <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">AI trip planner</span>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight">Build itinerary</h1>

          <div className="mt-7 flex flex-col gap-5">
            <label className="flex flex-col gap-2 text-sm font-semibold text-[var(--text-secondary)]">
              Destination Place ID
              <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-base)] px-4 py-3 font-mono text-sm text-[var(--text-primary)] select-all">
                {form.placeId}
              </div>
            </label>
            <label className="flex flex-col gap-2 text-sm font-semibold text-[var(--text-secondary)]">
              Days
              <InputNumber value={form.days} onValueChange={(event) => updateField("days", event.value || 1)} min={1} max={30} showButtons />
            </label>
            <label className="flex flex-col gap-2 text-sm font-semibold text-[var(--text-secondary)]">
              Budget
              <Dropdown value={form.budget} options={budgetOptions} onChange={(event) => updateField("budget", event.value)} />
            </label>
            <label className="flex flex-col gap-2 text-sm font-semibold text-[var(--text-secondary)]">
              Travel style
              <Dropdown value={form.travelStyle} options={styleOptions} onChange={(event) => updateField("travelStyle", event.value)} />
            </label>
            <label className="flex flex-col gap-2 text-sm font-semibold text-[var(--text-secondary)]">
              Interests
              <Chips value={form.interests} onChange={(event) => updateField("interests", event.value)} separator="," />
            </label>
          </div>

          {error && <Message severity="error" text={error} className="mt-5 w-full" />}

          <Button type="submit" label="Generate" icon="pi pi-sparkles" loading={loading} className="mt-7 w-full justify-center" />
        </form>

        {/* Timeline Panel */}
        <div className="rounded-[28px] border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-sm print-full md:p-8">
          {!itinerary ? (
            <div className="grid min-h-[520px] place-items-center text-center text-[var(--text-secondary)]">
              <div>
                <i className="pi pi-map-marker text-4xl mb-4 block opacity-50" />
                <p className="text-sm">Your generated itinerary will appear here.</p>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-[var(--border-subtle)] pb-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                    {itinerary.destination}
                  </span>
                  <h2 className="mt-2 text-3xl font-extrabold tracking-tight">{itinerary.tripSummary}</h2>
                </div>
                <Button
                  label="Export PDF"
                  icon="pi pi-file-pdf"
                  onClick={() => window.print()}
                  className="p-button-outlined shrink-0 no-print"
                />
              </div>

              <div className="mt-6 grid gap-4 md:grid-cols-2 no-print">
                <Info label="Estimated Budget" value={itinerary.estimatedBudget} />
                <Info label="Best Time to Visit" value={itinerary.bestTimeToVisit} />
              </div>

              {itinerary.packingEssentials?.length > 0 && (
                <div className="mt-6 no-print rounded-2xl bg-[var(--bg-surface-raised)]/40 p-4 border border-[var(--border-subtle)]">
                  <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                    Packing Essentials
                  </span>
                  <ul className="mt-2 text-sm leading-6 text-[var(--text-primary)] list-disc pl-4 space-y-1">
                    {itinerary.packingEssentials.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="mt-8 space-y-6">
                {itinerary.days?.map((day) => (
                  <article key={day.day} className="rounded-[20px] border border-[var(--border-subtle)] bg-[var(--bg-surface-raised)]/30 p-5 shadow-sm">
                    <h3 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">
                      Day {day.day}: {day.title}
                    </h3>
                    <div className="mt-4 space-y-4">
                      {day.activities?.map((activity, index) => (
                        <div key={`${day.day}-${index}`} className="rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]/40 p-4">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                            {activity.time}
                          </span>
                          <h4 className="mt-1 text-md font-semibold text-[var(--text-primary)]">
                            {activity.activity}
                          </h4>
                          <p className="mt-1 text-sm leading-6 text-[var(--text-secondary)]">
                            {activity.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </article>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Info({ label, value }) {
  return (
    <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface-raised)]/50 p-4">
      <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">{label}</span>
      <p className="mt-1 text-[15px] font-semibold text-[var(--text-primary)]">{value || "Not available"}</p>
    </div>
  );
}
